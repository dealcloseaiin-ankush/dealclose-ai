const aiService = require('../services/aiService');
const User = require('../models/userModel');
const Message = require('../models/messageModel');
const Lead = require('../models/leadModel'); 
const Flow = require('../models/flowModel'); 
const metaService = require('../services/metaAdsService');
const metaAdsService = require('../services/metaAdsService');
const axios = require('axios'); 
const googleSheetsController = require('./googleSheetsController');
const { getMessageExpiry } = require('../utils/retentionPolicy'); // 🚀 URGENT FIX: Re-added the missing import.
const IORedis = require('ioredis');

// Lightweight Redis client for deduplication and rate-limits (falls back to local)
const redis = process.env.REDIS_URL ? new IORedis(process.env.REDIS_URL) : new IORedis({ host: '127.0.0.1', port: 6379 });
redis.on && redis.on('error', (e) => console.error('⚠️ [Redis] Connection error in IG webhook controller:', e.message));
const THREAD_STATE_TTL = 30 * 24 * 60 * 60; // 30 days

// ✅ HELPER: Central place to check if a loginType is the "Instagram-native" flow
// (Business Login for Instagram, using graph.instagram.com endpoints).
// Anything else falls back to the Facebook-linked flow (graph.facebook.com).
const isInstagramNativeLogin = (loginType) =>
  loginType === 'instagram_basic_display' || loginType === 'instagram_business_login';

const loadThreadState = async (threadKey) => {
  try {
    const raw = await redis.get(threadKey);
    if (!raw) return {
      lastAuthorId: null,
      aiReplyCount: 0,
      humanTookOver: false,
      pausedUntil: null,
      manualOverride: false,
      lastAiReplyAt: null
    };
    return JSON.parse(raw);
  } catch (e) {
    console.error('⚠️ [Redis ThreadState] Load error:', e.message);
    return {
      lastAuthorId: null,
      aiReplyCount: 0,
      humanTookOver: false,
      pausedUntil: null,
      manualOverride: false,
      lastAiReplyAt: null
    };
  }
};

const saveThreadState = async (threadKey, state) => {
  try {
    await redis.set(threadKey, JSON.stringify(state), 'EX', THREAD_STATE_TTL);
  } catch (e) {
    console.error('⚠️ [Redis ThreadState] Save error:', e.message);
  }
};

// 🚀 OVERRIDE FOR SAFETY: Bypassing any hidden bugs inside metaAdsService.js
metaService.getInstagramProfile = async (token, userId, loginType = 'facebook_business') => {
  if (!token) {
    throw new Error("No Access Token found for profile fetch (Token is NULL)");
  }

  const isBasicDisplay = isInstagramNativeLogin(loginType);

  const url = isBasicDisplay
    ? `https://graph.instagram.com/v21.0/${userId}`
    : `https://graph.facebook.com/v19.0/${userId}`;

  const params = isBasicDisplay
    ? { fields: 'id,username,name,profile_picture_url', access_token: token }
    : { fields: 'name,profile_pic', access_token: token };

  try {
    const response = await axios.get(url, { params });
    // Normalize the response to match the expected structure
    return isBasicDisplay ? response.data : { name: response.data.name, username: response.data.name, profile_pic: response.data.profile_pic };
  } catch (error) {
    const metaErr = error.response?.data?.error;
    console.error(`❌ [META API PROFILE FETCH REJECTED] Failed to fetch profile for ID ${userId} via ${url}. Reason:`, metaErr?.message || error.message);
    throw error;
  }
};

// 🚀 OVERRIDE FOR SAFETY: Bypassing any hidden bugs inside metaAdsService.js
metaAdsService.sendInstagramDM = async (token, recipientId, text, loginType = 'facebook_business') => {
  if (!token) {
    throw new Error("No Access Token found (Token is NULL)");
  }

  // ✅ FIX 1: Now checks both 'instagram_basic_display' AND 'instagram_business_login'
  const baseUrl = isInstagramNativeLogin(loginType)
    ? 'https://graph.instagram.com/v21.0/me/messages'
    : 'https://graph.facebook.com/v19.0/me/messages';

  console.log(`\n▶️ [MEGA DEBUG: ID TRACKER FOR SENDING] Host: ${baseUrl}, Recipient: ${recipientId}, loginType: ${loginType}`);

  try {
    const response = await axios.post(baseUrl, {
      recipient: { id: recipientId },
      message: { text: text },
      messaging_type: "RESPONSE"
    }, { params: { access_token: token } });

    console.log(`✅ [META API SUCCESS] Message ID: ${response.data?.message_id}`);
    return response;
  } catch (error) {
    const metaErr = error.response?.data?.error;
    console.error(`❌ [META API REJECTED] Failed to send to ID ${recipientId} via ${baseUrl}. Reason:`, metaErr?.message || error.message);
    throw error;
  }
};

metaAdsService.sendInstagramCommentPrivateReply = async (token, pageId, commentId, text, loginType = 'facebook_business') => {
  if (!token) {
    throw new Error("No Access Token found for private reply (Token is NULL)");
  }

  // ✅ FIX 2: Now checks both 'instagram_basic_display' AND 'instagram_business_login'
  const useNativeFlow = isInstagramNativeLogin(loginType);

  const url = useNativeFlow
    ? `https://graph.instagram.com/v21.0/${commentId}/replies` // Instagram-native flow: verify against current Meta docs before finalizing this endpoint if private-reply-to-DM isn't supported
    : `https://graph.facebook.com/v19.0/${pageId}/messages`;

  if (!useNativeFlow && !pageId) {
    throw new Error("No Facebook Page ID found for private reply (pageId is NULL)");
  }

  const payload = useNativeFlow
    ? { message: text, access_token: token }
    : { recipient: { comment_id: commentId }, message: { text }, messaging_type: "RESPONSE" };

  try {
    const response = useNativeFlow
      ? await axios.post(url, payload)
      : await axios.post(url, payload, { params: { access_token: token } });
    console.log("[PRIVATE REPLY SUCCESS]", response.data);
    return response;
  } catch (error) {
    const metaErr = error.response?.data?.error;
    console.error("[PRIVATE REPLY REJECTED]", error.response?.data || error.message);
    throw error;
  }
};

// @desc     Verify Instagram Webhook Setup (Required by Meta)
// @route    GET /api/webhooks/instagram
exports.verifyInstagramWebhook = async (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  console.log(`\n🔍 [IG Webhook Verify Request] Mode: ${mode}, Token: ${token}`);

  if (!mode && !token) {
    return res.status(200).send("🚀 DealClose AI Instagram Webhook is LIVE and securely running! Waiting for Meta's POST requests.");
  }

  if (mode === 'subscribe' && (token === process.env.META_WEBHOOK_VERIFY_TOKEN || token === 'ankush@7828289433')) {
    console.log('✅ Instagram Webhook Verified Successfully!');
    return res.status(200).send(challenge);
  } else {
    console.error('❌ Instagram Webhook Verification Failed! Token Mismatch.');
  }
  return res.sendStatus(403);
};

// @desc     Handle Instagram Webhooks (Comments & DMs)
// @route    POST /api/webhooks/instagram
exports.handleInstagramWebhook = async (req, res) => {
  // 1. IMMEDIATE RESPONSE TO META: Prevents Meta from retrying
  res.status(200).send('EVENT_RECEIVED');
  
  console.log("\n================ [INSTAGRAM WEBHOOK INCOMING] ================");
  console.log("➡️ Headers:", JSON.stringify(req.headers));
  console.log("➡️ Raw Payload:", JSON.stringify(req.body, null, 2));
  
  try {
    const body = req.body;

    if (body.object === 'instagram' || body.object === 'page') {
      for (let entry of body.entry) {
        const igAccountId = entry.id;
        
        // ==========================================
        // 1. HANDLE DIRECT MESSAGES (DMs)
        // ==========================================
        if (entry.messaging && entry.messaging.length > 0) {
          for (let event of entry.messaging) {
            // 🐛 FIX: Add a safety check to handle non-text events like 'read' receipts.
            // The server was crashing because it tried to access `event.message.text`
            // on events that don't have a `message` object (e.g., read receipts).
            if (event.read) {
              console.log(`[IG Webhook] Ignoring 'read' receipt event from ${event.sender.id}.`);
              continue; // Skip to the next event
            } else if (event.message_edit) {
              // 🚀 NEW: Handle message edit/unsend events from Instagram.
              // This prevents crashes and logs the event, but doesn't trigger AI.
              console.log(`[IG Webhook] Ignoring 'message_edit' or 'unsend' event from ${event.sender.id}.`);
              continue;
            } else if (event.message && event.message.attachments) {
              // 🚀 NEW: Handle shared posts, reels, stories, etc.
              const attachment = event.message.attachments[0];
              console.log(`[IG Webhook] Received an attachment of type: ${attachment.type}`);
              
              const senderId = event.sender.id;
              const user = await User.findOne({ $or: [ { "instagramConfig.instagramBusinessAccountId": igAccountId }, { "workspaces.instagramConfig.instagramBusinessAccountId": igAccountId } ] }).lean();
              if (!user) continue;

              const workspace = user.workspaces?.find(w => w.instagramConfig?.instagramBusinessAccountId === igAccountId);
              const igToken = workspace?.instagramConfig?.accessToken || user.instagramConfig?.accessToken;
              const loginType = workspace?.instagramConfig?.loginType || user.instagramConfig?.loginType || 'facebook_business';

              if (igToken) {
                const replyText = "Thanks for sharing! Let me know if you have any questions about this.";
                await metaAdsService.sendInstagramDM(igToken, senderId, replyText, loginType).catch(e => console.error("Failed to send attachment ack:", e.message));
                await Message.create({ userId: user._id, customerPhone: `IG_${senderId}`, channel: 'instagram_dm', messageText: `[Customer shared a ${attachment.type}]`, direction: 'incoming', status: 'received', sentBy: 'customer', timestamp: new Date() });
                await Message.create({ userId: user._id, customerPhone: `IG_${senderId}`, channel: 'instagram_dm', messageText: replyText, direction: 'outgoing', status: 'sent', sentBy: 'auto-reply', timestamp: new Date() });
              }
              continue;

            } else if (event.message && event.message.text) {
              
              const isEcho = event.message.is_echo;
              const appId = event.message.app_id;
              const myAppId = process.env.META_APP_ID;

              if (isEcho && appId && myAppId && appId.toString() === myAppId.toString()) {
                 console.log(`🔇 [IG Webhook] Ignoring API echo message (Bot's own API reply).`);
                 continue;
              }

              const senderId = isEcho ? event.recipient.id : event.sender.id;
              const incomingText = event.message.text.trim();
              
              console.log(` [Meta DM (IG/FB)] ${isEcho ? 'Owner App Reply to' : 'Received from'} ${senderId}: ${incomingText}`);
 
              // ✅ FIX: The query was not checking for the user ID (`instagramUserId`) from the newer
              // "Instagram Login" flow, causing DMs to those accounts to fail with "No matching account found".
              // This now checks all possible ID fields across the main config and workspaces.
              let user = await User.findOne({
                $or: [
                  { "instagramConfig.instagramBusinessAccountId": igAccountId },
                  { "instagramConfig.instagramUserId": igAccountId },
                  { "workspaces.instagramConfig.instagramBusinessAccountId": igAccountId },
                  { "workspaces.instagramConfig.instagramUserId": igAccountId },
                ]
              }).lean();
              
              if (!user) {
                 console.log(`❌ [IG Webhook - DMs] No matching Instagram account found in DB for Webhook IG ID: ${igAccountId}`);
                 continue;
              }

              console.log(`\n✅ [IG Webhook - DMs] STRICT MATCH SUCCESS!`);
              console.log(`- Webhook IG Account ID:`, igAccountId);
              console.log(`- Matched User Email:`, user?.email);

              let igToken = null;
              let igPageId = null;
              let incomingWorkspaceId = 'main';
              let loginType = 'facebook_business'; // Default
              let activeWorkspace = null;
              
              if (user && user.workspaces && user.workspaces.length > 0) {
                  activeWorkspace = user.workspaces.find(w => w?.instagramConfig?.instagramBusinessAccountId === igAccountId);
                  const workspaceInstagram = activeWorkspace?.instagramConfig;
                  if (workspaceInstagram?.accessToken) {
                     igToken = workspaceInstagram.accessToken;
                     igPageId = workspaceInstagram.facebookPageId;
                     loginType = workspaceInstagram.loginType || 'facebook_business';
                     incomingWorkspaceId = activeWorkspace._id ? activeWorkspace._id.toString() : 'main';
                 }
              }
              
              if (!igToken && user && user.instagramConfig && user.instagramConfig.accessToken) {
                  igToken = user.instagramConfig.accessToken;
                  igPageId = user.instagramConfig.facebookPageId;
                  loginType = user.instagramConfig.loginType || 'facebook_business';
                  incomingWorkspaceId = 'main';
              }

              let realName = `IG User ${senderId.slice(-4)}`;
              if (igToken) {
                try {
                  const profile = await metaService.getInstagramProfile(igToken, senderId, loginType);
                  if (profile && (profile.name || profile.username)) {
                    realName = profile.name || profile.username;
                  }
                } catch (e) {
                  console.log("⚠️ Could not fetch IG profile details for", senderId);
                }
              }

              const quickReplyPayload = event.message?.quick_reply?.payload || event.postback?.payload || null;
              if (quickReplyPayload && quickReplyPayload.startsWith('GET_AUTO_LINK_')) {
                const postId = quickReplyPayload.replace('GET_AUTO_LINK_', '');
                
                const automationsSource = incomingWorkspaceId !== 'main' ? activeWorkspace?.postAutomations : user.postAutomations;
                const matchedRule = automationsSource?.find(r => r.postId === postId);
                
                if (matchedRule && matchedRule.fileUrl) {
                   const linkMsg = `Here is your requested link/file: ${matchedRule.fileUrl}\n\nLet me know if you need anything else!`;
                   if (igToken) await metaAdsService.sendInstagramDM(igToken, senderId, linkMsg, loginType).catch(e => console.error(e));
                   
                   if (incomingWorkspaceId !== 'main') {
                     await User.updateOne(
                       { _id: user._id, "workspaces._id": incomingWorkspaceId },
                       { $inc: { "workspaces.$.postAutomations.$[elem].stats.clickedCount": 1 } },
                       { arrayFilters: [{ "elem.postId": postId }] }
                     ).catch(e => console.log('Workspace click count increment error:', e.message));
                   } else {
                     await User.updateOne(
                       { _id: user._id, "postAutomations.postId": postId },
                       { $inc: { "postAutomations.$.stats.clickedCount": 1 } }
                     ).catch(e => console.log('Main click count increment error:', e.message));
                   }
                   
                   await Message.create({ userId: user._id, workspaceId: incomingWorkspaceId, customerPhone: `IG_${senderId}`, channel: 'instagram_dm', messageText: linkMsg, direction: 'outgoing', status: 'sent', sentBy: 'auto-reply', timestamp: new Date(), expiresAt: getMessageExpiry(user, 'instagram_dm', 'auto-reply') });
                   continue; 
                }
              }

              // 🛠️ BUG FIX: this "incoming from customer" log used to run unconditionally,
              // BEFORE the isEcho check below. That meant every time the owner replied from
              // their own Instagram app (an echo event), their own reply text got logged into
              // the chat as if the *customer* had said it — corrupting chat history and
              // confusing the AI context on every future message. We now only log it here
              // when it is genuinely an incoming customer message; the echo branch logs its
              // own correct 'outgoing' record below.
              if (!isEcho) {
                await Message.create({
                  userId: user._id,
                  customerPhone: `IG_${senderId}`, 
                  channel: 'instagram_dm',
                  messageText: incomingText,
                  direction: 'incoming',
                  status: 'received',
                  sentBy: 'customer',
                  timestamp: new Date(),
                  expiresAt: getMessageExpiry(user, 'instagram_dm', 'incoming')
                });
              }
              let currentLeadCheck = await Lead.findOne({ phoneNumber: `IG_${senderId}`, userId: user._id });
              
              if (isEcho) {
                 await Message.create({
                   userId: user._id,
                   customerPhone: `IG_${senderId}`,
                   channel: 'instagram_dm',
                   messageText: incomingText,
                   direction: 'outgoing',
                   status: 'sent',
                   sentBy: 'owner_app',
                   timestamp: new Date(),
                   expiresAt: getMessageExpiry(user, 'instagram_dm', 'outgoing')
                 });

                 await Lead.findOneAndUpdate(
                   { phoneNumber: `IG_${senderId}`, userId: user._id },
                   { $set: { isAiPaused: true, aiPausedUntil: new Date(Date.now() + 24 * 60 * 60 * 1000) } }
                 );
                 console.log(`⏸️ [IG Webhook] Owner replied from IG App. AI Paused.`);
                 continue; 
              }

              const isCurrentlyPaused = currentLeadCheck && currentLeadCheck.isAiPaused && currentLeadCheck.aiPausedUntil > new Date();
              
              if (isCurrentlyPaused) {
                console.log(`⏸️ [IG Webhook] Human context taken over chat for ${senderId}. Skipping AI.`);
                continue; 
              } else if (currentLeadCheck && currentLeadCheck.isAiPaused) {
                await Lead.updateOne({ _id: currentLeadCheck._id }, { $set: { isAiPaused: false, aiPausedUntil: null } });
              }

              const incomingTextLower = incomingText.toLowerCase();
              let flowReplyHandled = false;
              
              const formatFlowMsg = (text) => {
                if (!text) return "";
                let cName = realName.startsWith('IG User') ? '' : realName.split(' ')[0];
                return text.replace(/\{\{name\}\}/gi, cName ? cName : 'there');
              };

              const sendIGFlowMessage = async (text, nodeToPauseAt = null, flowIdToPauseAt = null, loginTypeParam) => {
                let deliveryStatus = 'sent';
                let displayMsg = text;
                try {
                    if (!igToken) throw new Error("IG Token is missing or invalid");
                    await metaAdsService.sendInstagramDM(igToken, senderId, text, loginTypeParam || loginType);
                } catch (e) {
                    console.error("❌ [IG Flow DM Error]:", e.message);
                    deliveryStatus = 'failed';
                    displayMsg += `\n\n[⚠️ Failed to Send IG DM: ${e.message}]`;
                }
                await Message.create({ userId: user._id, customerPhone: `IG_${senderId}`, channel: 'instagram_dm', messageText: displayMsg, direction: 'outgoing', status: deliveryStatus, sentBy: 'auto-reply', timestamp: new Date(), expiresAt: getMessageExpiry(user, 'instagram_dm', 'auto-reply') });
                if (nodeToPauseAt && flowIdToPauseAt) {
                    if (!currentLeadCheck) {
                        currentLeadCheck = await Lead.findOneAndUpdate(
                            { phoneNumber: `IG_${senderId}`, userId: user._id },
                            {
                                $setOnInsert: {
                                    name: realName,
                                    source: 'Instagram DM',
                                    status: 'visitor',
                                    createdBy: user._id
                                }
                            }, 
                            { upsert: true, new: true }
                        );
                    }
                    await Lead.updateOne({ _id: currentLeadCheck._id }, { $set: { activeFlowState: { flowId: flowIdToPauseAt, nodeId: nodeToPauseAt } } }, { strict: false });
                }
              };

              // 🚀 FIX: Stricter flow filtering by platform and workspace
              let flowQuery = { userId: user._id, platform: 'instagram' };
              if (incomingWorkspaceId !== 'main') {
                  // Only fetch flows for this specific workspace
                  flowQuery.workspaceId = incomingWorkspaceId;
              }
              const userFlows = await Flow.find(flowQuery);

              // Check if the lead is in the middle of a flow
              if (currentLeadCheck && currentLeadCheck.activeFlowState && currentLeadCheck.activeFlowState.flowId) {
                const activeFlow = userFlows.find(f => f._id.toString() === currentLeadCheck.activeFlowState.flowId);
                if (activeFlow && activeFlow.flowData) {
                  const nodes = activeFlow.flowData.nodes || [];
                  const edges = activeFlow.flowData.edges || [];
                  const activeNode = nodes.find(n => n.id === currentLeadCheck.activeFlowState.nodeId);

                  if (activeNode) {
                     let chosenEdge = null;
                     if (activeNode.type === 'askQuestion') {
                         if (activeNode.data.replyType === 'open') {
                             // 🚀 FIX: Defined the missing 'qLower' variable.
                             const qLower = (activeNode.data.question || '').toLowerCase(); 
                             const updatePayload = { $push: { notes: `Flow Answer (${activeNode.data.question}): ${incomingText}` } }; 
                             if (currentLeadCheck.status === 'visitor' && (qLower.includes('brand') || qLower.includes('budget') || qLower.includes('city') || qLower.includes('name'))) {
                                 updatePayload.$set = { status: 'new' };
                             }
                             await Lead.updateOne({ _id: currentLeadCheck._id }, updatePayload, { strict: false });
                             chosenEdge = edges.find(e => e.source === activeNode.id && e.sourceHandle === 'replied');
                         } else {
                             if (['yes', 'y', 'ha', 'haan', 'han'].includes(incomingTextLower)) {
                                 chosenEdge = edges.find(e => e.source === activeNode.id && e.sourceHandle === 'yes');
                             } else if (['no', 'n', 'na', 'nahi', 'nahin'].includes(incomingTextLower)) {
                                 chosenEdge = edges.find(e => e.source === activeNode.id && e.sourceHandle === 'no');
                             } else {
                                 chosenEdge = edges.find(e => e.source === activeNode.id && e.sourceHandle === 'other');
                             }
                         }
                     } else if (activeNode.type === 'menu') {
                         const incLower = incomingText.toLowerCase();
                         if (activeNode.data.opt1 && incLower === activeNode.data.opt1.toLowerCase()) chosenEdge = edges.find(e => e.source === activeNode.id && e.sourceHandle === 'opt_0');
                         else if (activeNode.data.opt2 && incLower === activeNode.data.opt2.toLowerCase()) chosenEdge = edges.find(e => e.source === activeNode.id && e.sourceHandle === 'opt_1');
                         else if (activeNode.data.opt3 && incLower === activeNode.data.opt3.toLowerCase()) chosenEdge = edges.find(e => e.source === activeNode.id && e.sourceHandle === 'opt_2');
                         else {
                             const num = parseInt(incomingText.trim(), 10);
                             if (num === 1) chosenEdge = edges.find(e => e.source === activeNode.id && e.sourceHandle === 'opt_0');
                             else if (num === 2) chosenEdge = edges.find(e => e.source === activeNode.id && e.sourceHandle === 'opt_1');
                             else if (num === 3) chosenEdge = edges.find(e => e.source === activeNode.id && e.sourceHandle === 'opt_2');
                             else chosenEdge = edges.find(e => e.source === activeNode.id && e.sourceHandle === 'opt_0'); 
                         }
                     }

                     await Lead.updateOne({ _id: currentLeadCheck._id }, { $unset: { activeFlowState: 1 } }, { strict: false });

                     let currNodeId = chosenEdge ? chosenEdge.target : null;
                     while (currNodeId) {
                       const nextNode = nodes.find(n => n.id === currNodeId);
                       if (!nextNode) break;
                       const currentFlowId = activeFlow._id.toString();
                       
                       if (nextNode.type === 'message') {
                         const msgText = formatFlowMsg(nextNode.data.message || nextNode.data.label);
                         await sendIGFlowMessage(msgText, null, null, loginType);
                         let nextE = edges.find(e => e.source === nextNode.id);
                         currNodeId = nextE ? nextE.target : null;
                       } else if (nextNode.type === 'askQuestion') {
                         const msgText = formatFlowMsg(nextNode.data.question || nextNode.data.label);
                         await sendIGFlowMessage(msgText, nextNode.id, currentFlowId, loginType);
                         currNodeId = null; 
                       } else if (nextNode.type === 'menu') {
                         let msgText = formatFlowMsg(nextNode.data.message || "Please choose an option:");
                         const options = [nextNode.data.opt1, nextNode.data.opt2, nextNode.data.opt3].filter(opt => opt && opt.trim() !== '');
                         if (options.length > 0) {
                           msgText += "\n";
                           options.forEach((opt, idx) => { msgText += `\n${idx+1}️⃣ ${opt}`; });
                           msgText += "\n\n(Type a number)";
                           await sendIGFlowMessage(msgText, nextNode.id, currentFlowId, loginType);
                         }
                         currNodeId = null; 
                       } else if (nextNode.type === 'add_tag' || nextNode.type === 'tag_lead') {
                         if (nextNode.data.tag) await Lead.updateOne({ _id: currentLeadCheck._id }, { $addToSet: { tags: nextNode.data.tag } }, { strict: false });
                         let nextE = edges.find(e => e.source === nextNode.id);
                         currNodeId = nextE ? nextE.target : null;
                       } else if (nextNode.type === 'crm_update') {
                         const updateFields = {};
                         if (nextNode.data.status) updateFields.status = nextNode.data.status;
                         if (nextNode.data.leadScore) updateFields.leadScore = parseInt(nextNode.data.leadScore, 10);
                         if (nextNode.data.budget) updateFields.budget = nextNode.data.budget;
                         if (Object.keys(updateFields).length > 0) await Lead.updateOne({ _id: currentLeadCheck._id }, { $set: updateFields }, { strict: false });
                         let nextE = edges.find(e => e.source === nextNode.id);
                         currNodeId = nextE ? nextE.target : null;
                       } else if (nextNode.type === 'human_handover' || nextNode.type === 'assign_staff') {
                         await Lead.updateOne({ _id: currentLeadCheck._id }, { $set: { isAiPaused: true, aiPausedUntil: new Date(Date.now() + 24 * 60 * 60 * 1000) } }, { strict: false });
                         let nextE = edges.find(e => e.source === nextNode.id);
                         currNodeId = nextE ? nextE.target : null;
                       } else if (nextNode.type === 'google_sheet') {
                         const freshLead = await Lead.findById(currentLeadCheck._id);
                         googleSheetsController.appendLeadToSheet(user._id, freshLead).catch(e => console.log('Sheets sync error:', e.message));
                         let nextE = edges.find(e => e.source === nextNode.id);
                         currNodeId = nextE ? nextE.target : null;
                       } else if (nextNode.type === 'ai_agent') {
                         await Lead.updateOne({ _id: currentLeadCheck._id }, { $unset: { activeFlowState: 1 } }, { strict: false });
                         if (nextNode.data.message) await sendIGFlowMessage(formatFlowMsg(nextNode.data.message), null, null, loginType);
                         currNodeId = null; 
                       } else { break; }
                     }
                     flowReplyHandled = true;
                  }
                }
              }

              if (!flowReplyHandled) {
                for (const flow of userFlows) {
                  if (!flow.flowData) continue;
                  const nodes = flow.flowData.nodes || [];
                  const edges = flow.flowData.edges || [];
                  const triggerNodes = nodes.filter(n => n.type === 'trigger' && n.data.triggerType === 'keyword');
                  
                  let matchedTrigger = null;
                  for (const trigger of triggerNodes) {
                    const keywords = (trigger.data.keyword || "").split(',').map(k => k.trim().toLowerCase());
                    const words = incomingTextLower.split(/[\s,]+/);
                    if (keywords.some(k => incomingTextLower === k || words.includes(k))) {
                      matchedTrigger = trigger;
                      break;
                    }
                  }

                  if (matchedTrigger) {
                    let nextEdge = edges.find(e => e.source === matchedTrigger.id);
                    let currNodeId = nextEdge ? nextEdge.target : null;
                    
                    let circuitBreaker = 0;
                    while (currNodeId && circuitBreaker < 20) {
                       circuitBreaker++;
                       const nextNode = nodes.find(n => n.id === currNodeId);
                       if (!nextNode) break;
                       if (nextNode.type === 'message') {
                         const msgText = formatFlowMsg(nextNode.data.message || nextNode.data.label);
                         await sendIGFlowMessage(msgText, null, null, loginType);
                         let nextE = edges.find(e => e.source === nextNode.id);
                         currNodeId = nextE ? nextE.target : null;
                       } else if (nextNode.type === 'askQuestion') {
                         const msgText = formatFlowMsg(nextNode.data.question || nextNode.data.label);
                         await sendIGFlowMessage(msgText, nextNode.id, flow._id.toString(), loginType);
                         currNodeId = null; 
                       } else if (nextNode.type === 'menu') {
                         let msgText = formatFlowMsg(nextNode.data.message || "Please choose an option:");
                         const options = [nextNode.data.opt1, nextNode.data.opt2, nextNode.data.opt3].filter(opt => opt && opt.trim() !== '');
                         if (options.length > 0) {
                           msgText += "\n";
                           options.forEach((opt, idx) => { msgText += `\n${idx+1}️⃣ ${opt}`; });
                           msgText += "\n\n(Type a number)";
                           await sendIGFlowMessage(msgText, nextNode.id, flow._id.toString(), loginType);
                         }
                         currNodeId = null; 
                       } else { break; }
                    }
                    flowReplyHandled = true;
                    break;
                  }
                }
              }

              if (flowReplyHandled) {
                continue; 
              }

              const dmAutomationSource = incomingWorkspaceId !== 'main' ? (activeWorkspace?.postAutomations || []) : (user.postAutomations || []);
              if (!flowReplyHandled && dmAutomationSource.length > 0) {
                const matchedAuto = dmAutomationSource.find(rule => incomingTextLower.includes((rule.triggerWord || '').toLowerCase()));
                if (matchedAuto && matchedAuto.fileUrl) {
                  try {
                    if (matchedAuto.deliveryMode === 'button') {
                      // ✅ FIX 5: quick reply URL now checks both native-login values
                      const quickReplyUrl = isInstagramNativeLogin(loginType)
                        ? 'https://graph.instagram.com/v21.0/me/messages'
                        : 'https://graph.facebook.com/v19.0/me/messages';
                      await axios.post(quickReplyUrl, {
                        recipient: { id: senderId },
                        message: {
                          text: `${matchedAuto.replyMessage}\n\nTap the button below to receive the file/link:`,
                          quick_replies: [{ content_type: "text", title: "Get Link 🔗", payload: `GET_AUTO_LINK_${matchedAuto.postId}` }]
                        }
                      }, { params: { access_token: igToken } });
                    } else {
                      const directLinkMsg = `${matchedAuto.replyMessage}\n\n📄 Link: ${matchedAuto.fileUrl}`;
                      // ✅ FIX 4: loginType was missing here before, causing default 'facebook_business' to be used
                      if (igToken) await metaAdsService.sendInstagramDM(igToken, senderId, directLinkMsg, loginType);
                      if (incomingWorkspaceId !== 'main') {
                        await User.updateOne(
                          { _id: user._id, "workspaces._id": incomingWorkspaceId },
                          { $inc: { "workspaces.$.postAutomations.$[elem].stats.clickedCount": 1 } },
                          { arrayFilters: [{ "elem.postId": matchedAuto.postId }] }
                        );
                      } else {
                        await User.updateOne({ _id: user._id, "postAutomations.postId": matchedAuto.postId }, { $inc: { "postAutomations.$.stats.clickedCount": 1 } });
                      }
                    }
                    
                    if (incomingWorkspaceId !== 'main') {
                      await User.updateOne(
                        { _id: user._id, "workspaces._id": incomingWorkspaceId },
                        { $inc: { "workspaces.$.postAutomations.$[elem].stats.sentCount": 1 } },
                        { arrayFilters: [{ "elem.postId": matchedAuto.postId }] }
                      );
                    } else {
                      await User.updateOne({ _id: user._id, "postAutomations.postId": matchedAuto.postId }, { $inc: { "postAutomations.$.stats.sentCount": 1 } });
                    }
                    await Message.create({ userId: user._id, customerPhone: `IG_${senderId}`, channel: 'instagram_dm', messageText: `[Button Sent] ${matchedAuto.replyMessage}`, direction: 'outgoing', status: 'sent', sentBy: 'auto-reply', timestamp: new Date(), expiresAt: getMessageExpiry(user, 'instagram_dm', 'auto-reply') });
                  } catch(e) {
                    console.error("Quick Reply DM Error:", e.response?.data || e.message);
                  }
                  continue; 
                }
              }

              const isCreator = user.acceptCollabs === true;
              const isAiEnabled = incomingWorkspaceId !== 'main'
                ? activeWorkspace?.aiAgentEnabled === true
                : user.aiAgentEnabled === true;

              if (!isAiEnabled && ['hi', 'hello', 'hey', 'menu', 'collab'].includes(incomingTextLower)) {
                const menuMessage = isCreator 
                  ? `Hi! 👋 I am the automated manager for ${user.fullName || 'this creator'}.\n\nPlease tell me why you're reaching out (Type a number):\n1️⃣ Brand Promotion / Collaboration\n2️⃣ Just a Fan saying Hi! ❤️\n3️⃣ General Query`
                  : `Hi! 👋 Welcome to ${user.businessName || user.fullName}.\n\nHow can I help you today? (Type a number):\n1️⃣ Order / Buy a Product 🛒\n2️⃣ Customer Support 🎧\n3️⃣ Talk to our Team 👤`;
                  
                let deliveryStatus = 'sent';
                let displayMsg = menuMessage;
                try {
                  if (igToken) await metaAdsService.sendInstagramDM(igToken, senderId, menuMessage, loginType);
                } catch (apiErr) {
                  deliveryStatus = 'failed';
                  displayMsg += `\n\n[⚠️ Failed to Send IG DM: ${apiErr.message}]`;
                }

                await Message.create({ 
                  userId: user._id, 
                  customerPhone: `IG_${senderId}`, 
                  messageText: displayMsg, 
                  direction: 'outgoing', 
                  status: deliveryStatus, 
                  sentBy: 'auto-reply',
                  timestamp: new Date(),
                  channel: 'instagram_dm',
                  expiresAt: getMessageExpiry(user, 'instagram_dm', 'auto-reply')
                });
                continue; 
              }

              if (isCreator && (incomingTextLower === '1' || incomingTextLower.includes('collab') || incomingTextLower.includes('brand') || incomingTextLower.includes('promotion'))) {
                const collabMsg = `Thank you for your interest in collaborating! 🤝 Our team has received your request and will review it soon.`;
                
                let deliveryStatus = 'sent';
                let displayMsg = collabMsg;
                try {
                  if (igToken) await metaAdsService.sendInstagramDM(igToken, senderId, collabMsg, loginType);
                } catch (apiErr) {
                  deliveryStatus = 'failed';
                  displayMsg += `\n\n[⚠️ Failed to Send IG DM: ${apiErr.message}]`;
                }

                await Message.create({ 
                  userId: user._id, 
                  customerPhone: `IG_${senderId}`, 
                  messageText: displayMsg, 
                  direction: 'outgoing', 
                  status: deliveryStatus, 
                  sentBy: 'auto-reply',
                  timestamp: new Date(),
                  channel: 'instagram_dm',
                  expiresAt: getMessageExpiry(user, 'instagram_dm', 'auto-reply')
                });
                continue; 
              }

              if (isCreator && (incomingTextLower === '2' || incomingTextLower.includes('fan'))) {
                const fanMsg = `Aww! Thank you so much for the love and support! Means the world to me. ❤️✨`;
                
                let deliveryStatus = 'sent';
                let displayMsg = fanMsg;
                try {
                  if (igToken) await metaAdsService.sendInstagramDM(igToken, senderId, fanMsg, loginType);
                } catch (apiErr) {
                  deliveryStatus = 'failed';
                  displayMsg += `\n\n[⚠️ Failed to Send IG DM: ${apiErr.message}]`;
                }

                await Message.create({ 
                  userId: user._id, 
                  customerPhone: `IG_${senderId}`, 
                  messageText: displayMsg, 
                  direction: 'outgoing', 
                  status: deliveryStatus, 
                  sentBy: 'auto-reply',
                  timestamp: new Date(),
                  channel: 'instagram_dm',
                  expiresAt: getMessageExpiry(user, 'instagram_dm', 'auto-reply')
                });
                continue; 
              }

              if (incomingTextLower === '3' || incomingTextLower.includes('general') || incomingTextLower.includes('human') || incomingTextLower.includes('team')) {
                const generalMessage = isCreator ? `Your query has been recorded. Our team will review it shortly.` : `Thanks! I've notified our team. A human representative will get back to you shortly. ⏳`;
                
                let deliveryStatus = 'sent';
                let displayMsg = generalMessage;
                try {
                  if (igToken) await metaAdsService.sendInstagramDM(igToken, senderId, generalMessage, loginType);
                } catch (apiErr) {
                  deliveryStatus = 'failed';
                  displayMsg += `\n\n[⚠️ Failed to Send IG DM: ${apiErr.message}]`;
                }

                await Message.create({ 
                  userId: user._id, 
                  customerPhone: `IG_${senderId}`, 
                  messageText: displayMsg, 
                  direction: 'outgoing', 
                  status: deliveryStatus, 
                  sentBy: 'auto-reply',
                  timestamp: new Date(),
                  channel: 'instagram_dm',
                  expiresAt: getMessageExpiry(user, 'instagram_dm', 'auto-reply')
                });
                continue; 
              }

              if (isAiEnabled) {
                try {
                  let businessInfo = activeWorkspace ? activeWorkspace.description : (user.businessDescription || "an Instagram Creator");
                  let ownerRules = activeWorkspace ? activeWorkspace.aiRules : (user.aiRules || "Be professional and negotiate politely.");
                  
                  let aiContext = "";
                  
                  if (isCreator) {
                    aiContext = `You are a professional Talent Manager AI for an influencer. 
Influencer Details/Media Kit: ${businessInfo}.
Rules: ${ownerRules}.
IMPORTANT: If the user's message is just "1", ask for brand name and deliverables first. 
Budget is OPTIONAL — many brands prefer to discuss budget after initial conversation. 
As soon as you have the brand name (even without budget), call the extract_brand_deal tool 
with whatever information is available (leave budget field empty/null if not provided).`;
                   
                 } else {
                    aiContext = `You are a highly skilled Sales AI Assistant for ${activeWorkspace ? activeWorkspace.name : (user.businessName || 'this business')}. 
                    Business Details/Catalog: ${businessInfo}.
                    Rules: ${ownerRules}.
                    IMPORTANT RULES: ALWAYS ask for Name, City, and WhatsApp Number before requirements tool execution.`;
                  }

                  const aiMessage = await aiService.generateAIResponseWithTools(incomingText, aiContext);
                  let responseMessage = null;

                  if (aiMessage.tool_calls && aiMessage.tool_calls.length > 0) {
                    for (const toolCall of aiMessage.tool_calls) {
                      if (toolCall.function.name === "extract_brand_deal" || toolCall.function.name === "extract_lead_requirements") {
                        const dealData = JSON.parse(toolCall.function.arguments);
                        const brandOrName = dealData.name || dealData.brandName;
                        
                        if (brandOrName && brandOrName.trim() !== '') {
                          // 🛠️ BUG FIX: filter was missing userId, so this could match and
                          // overwrite an Instagram lead belonging to a different business
                          // account (e.g. if the DM came in on a shared/duplicate sender id).
                          const updatedIgLead = await Lead.findOneAndUpdate(
                            { phoneNumber: `IG_${senderId}`, userId: user._id }, 
                            { 
                              $set: {
                                userId: user._id, 
                                name: brandOrName, 
                                source: 'Instagram DM (Promotion)', 
                                status: 'interested', 
                                notes: `Deliverables: ${dealData.itemName || dealData.deliverables || 'Not specified yet'} | Offered Budget: ${dealData.budget || 'Not specified — to be negotiated'}`
                              }
                            }, 
                            { upsert: true, returnDocument: 'after' }
                          );
                          
                          googleSheetsController.appendLeadToSheet(user._id, updatedIgLead).catch(e => console.log('Sheets sync error:', e.message));
                          responseMessage = `Thank you! I have noted down your details. Our team will get back to you shortly.`;
                        } else {
                          responseMessage = aiMessage.content;
                        }
                      }
                    }
                  } else {
                    responseMessage = aiMessage.content;
                  }

                  if (responseMessage) {
                    let deliveryStatus = 'sent';
                    let displayMsg = responseMessage;
                    try {
                      if (igToken) await metaAdsService.sendInstagramDM(igToken, senderId, responseMessage, loginType);
                    } catch (sendErr) {
                      deliveryStatus = 'failed';
                      displayMsg += `\n\n[⚠️ Failed to Send IG DM: ${sendErr.message}]`;
                    }
                    
                    await Message.create({
                      userId: user._id,
                      customerPhone: `IG_${senderId}`,
                      messageText: displayMsg,
                      direction: 'outgoing',
                      status: deliveryStatus,
                      sentBy: 'ai',
                      timestamp: new Date(),
                      channel: 'instagram_dm',
                      expiresAt: getMessageExpiry(user, 'instagram_dm', 'ai')
                    });
                  }

                } catch (aiErr) {
                  console.error("❌ [Instagram AI Error]:", aiErr.message);
                  await Message.create({
                    userId: user._id,
                    customerPhone: `IG_${senderId}`,
                    messageText: `[⚠️ AI System Alert: Failed to generate reply.]`,
                    direction: 'outgoing',
                    status: 'failed',
                    sentBy: 'system',
                    timestamp: new Date(),
                    channel: 'instagram_dm'
                  });
                }
              }
            }
          }
        }

        // ==========================================
        // 2. HANDLE COMMENTS 
        // ==========================================
        if (entry.changes && entry.changes[0].field === 'comments') {
          const commentData = entry.changes[0].value;
          const commentText = commentData.text;
          const igUserId = commentData.from.id;
          const username = commentData.from.username || `IG_User_${igUserId}`;
          const mediaId = commentData.media ? commentData.media.id : null;
          const threadId = commentData.parent_id || commentData.id || mediaId || 'unknown_thread';
          const threadKey = `ig_thread_state:${igAccountId}:${threadId}`;
          let threadState = await loadThreadState(threadKey);

          console.log(`[Meta Comment (IG/FB)] Received from ${username}: ${commentText}`);

          // ====== SELF-COMMENT / SELF-REPLY FILTER ======
          try {
            if (String(igUserId) === String(igAccountId)) {
              if (threadState.lastAiCommentId && String(threadState.lastAiCommentId) === String(commentData.id)) {
                console.log('Skipped: own AI reply acknowledgement event for thread', threadId);
                threadState.lastAuthorId = igAccountId;
                await saveThreadState(threadKey, threadState);
                continue;
              }

              threadState.humanTookOver = true;
              threadState.lastAuthorId = igAccountId;
              await saveThreadState(threadKey, threadState);
              console.log('Skipped: human takeover detected in thread', threadId, '- AI comment replies permanently disabled for this thread');
              continue;
            }
          } catch (e) {
            console.error('Error during self-comment check:', e.message);
          }

          // ====== DEDUPLICATION: prevent processing same comment twice ======
          const dedupKey = `processed_comment:${commentData.id}`;
          try {
            const already = await redis.get(dedupKey);
            if (already) {
              console.log('Skipped: duplicate comment (already processed within TTL)');
              continue;
            }
            await redis.set(dedupKey, '1', 'EX', 24 * 60 * 60);
          } catch (e) {
            console.error('⚠️ [Redis Dedup] Error checking/setting dedup key:', e.message);
          }

          // ✅ FIX: The query was not checking for the user ID (`instagramUserId`) from the newer
          // "Instagram Login" flow, causing comment replies for those accounts to fail.
          // This now checks all possible ID fields across the main config and workspaces.
          let user = await User.findOne({
             $or: [
               { "instagramConfig.instagramBusinessAccountId": igAccountId }, // New schema
               { "instagramConfig.instagramUserId": igAccountId },          // New schema (native login)
               { "workspaces.instagramConfig.instagramBusinessAccountId": igAccountId }, // New schema in workspace
               { "workspaces.instagramConfig.instagramUserId": igAccountId },          // New schema in workspace (native login)
               { "igConfig.instagramBusinessAccountId": igAccountId }, // 🚀 FIX: Check legacy igConfig field
             ]
          });
          
          if (!user) {
             console.log(`❌ [IG Webhook - Comments] No matching Instagram account found in DB for Webhook IG ID: ${igAccountId}`);
             continue;
          }
          
          let incomingWorkspaceId = 'main';
          let activeWorkspaceNode = null;
          let igToken = user.instagramConfig?.accessToken || user.igConfig?.accessToken;
          let igPageId = user.instagramConfig?.facebookPageId || user.igConfig?.facebookPageId || null;
          let loginType = user.instagramConfig?.loginType || 'facebook_business';
          console.log("[COMMENT WEBHOOK DEBUG] initial pageId:", igPageId, "initial token present:", Boolean(igToken));

          if (user.workspaces && user.workspaces.length > 0) {
             activeWorkspaceNode = user.workspaces.find(w => w?.instagramConfig?.instagramBusinessAccountId === igAccountId);
             if (activeWorkspaceNode?.instagramConfig?.accessToken) {
                igToken = activeWorkspaceNode.instagramConfig.accessToken;
                loginType = activeWorkspaceNode.instagramConfig.loginType || 'facebook_business';
                igPageId = activeWorkspaceNode.instagramConfig.facebookPageId || igPageId;
                incomingWorkspaceId = activeWorkspaceNode._id ? activeWorkspaceNode._id.toString() : 'main';
             }
          }

          const phoneRegex = /(?:\+?\d{1,3}[- ]?)?\d{10}/;
          const phoneMatch = commentText.match(phoneRegex);

          if (phoneMatch) {
             const extractedPhone = phoneMatch[0].replace(/\D/g, '');
             console.log(`[Comment Phone Detected] Number found in comment: ${extractedPhone}. Sending confirmation DM instead of creating lead directly.`);
             
             const confirmMsg = `Hi! Thanks for sharing your number. Could you please confirm your Name, City, and the WhatsApp number you'd like us to contact you on? 😊`;
             
             try {
               if (igToken && (igPageId || isInstagramNativeLogin(loginType))) {
                 await metaAdsService.sendInstagramCommentPrivateReply(igToken, igPageId, commentData.id, confirmMsg, loginType);
               }
             } catch (e) {
               console.error('Failed to send phone-confirmation DM:', e.message);
             }
             
             await Message.create({
               userId: user._id,
               customerPhone: `IG_${igUserId}`, 
               channel: 'instagram_comment',
               messageText: `[💬 IG Comment - Phone Detected, awaiting confirmation]: ${commentText}`,
               direction: 'incoming',
               status: 'received',
               sentBy: 'customer',
               tags: ['ig_comment', 'phone_detected_unconfirmed'],
               timestamp: new Date(),
               expiresAt: getMessageExpiry(user, 'instagram_comment', 'incoming')
             });
             continue; // Skip flow routing for phone capture drops
          }

          let matchedRule = null;
          let isPostSpecific = false;
          console.log("\n========================================================");
          console.log("[WEBHOOK ACCOUNT ANALYSIS]");
          console.log("META ENTRY ACCOUNT ID (igAccountId) =", igAccountId);
          console.log("INCOMING REEL/MEDIA ID (mediaId) =", mediaId);
          console.log("DETECTED WORKSPACE CONTEXT ID =", incomingWorkspaceId);
          console.log("COMMENT ID =", commentData.id);
          console.log("COMMENT USER ID =", igUserId);
          console.log("COMMENT USERNAME =", username);
          console.log("IG TOKEN AVAILABLE =", Boolean(igToken));
          console.log("\n[DATABASE LOCKS CHECK]");
          console.log("MAIN COLLECTION AUTOMATIONS (user.postAutomations) =",
            user.postAutomations?.map(r => ({ postId: r.postId, trigger: r.triggerWord, delivery: r.deliveryMode, url: r.fileUrl }))
          );

          if (user.workspaces && user.workspaces.length > 0) {
            console.log("AVAILABLE WORKSPACES IN DB =");
            user.workspaces.forEach(w => {
              console.log(`   - Name: ${w.name} | ID: ${w._id} | IG Account: ${w.instagramConfig?.instagramBusinessAccountId || 'N/A'}`);
              console.log(`     Rules Count: ${w.postAutomations?.length || 0}`);
              if (w.postAutomations && w.postAutomations.length > 0) {
                console.log("     Rules Array:", w.postAutomations.map(r => ({ postId: r.postId, trigger: r.triggerWord, delivery: r.deliveryMode, url: r.fileUrl })));
              }
            });
          } else {
            console.log("WORKSPACES ARRAY IS EMPTY IN USER OBJECT!");
          }
          console.log("========================================================\n");
          
          let searchRuleSource = [];
          if (incomingWorkspaceId !== 'main' && activeWorkspaceNode && activeWorkspaceNode.postAutomations) {
              searchRuleSource = activeWorkspaceNode.postAutomations;
              console.log(`[Match Engine] Searching rules inside Workspace source array: ${activeWorkspaceNode.name}`);
          } else {
              searchRuleSource = user.postAutomations || [];
              console.log("[Match Engine] Searching rules inside Main Account source array.");
          }

          if (searchRuleSource && searchRuleSource.length > 0) {
            if (mediaId) {
              matchedRule = searchRuleSource.find(rule => 
                String(rule.postId) === String(mediaId) && 
                commentText.toLowerCase().includes((rule.triggerWord || '').toLowerCase())
              );
              if (matchedRule) {
                isPostSpecific = true;
                console.log(`🎯 [Match Engine] Locked dynamic post route rule for Media: ${mediaId}`);
              }
            }
            if (!matchedRule) {
              matchedRule = searchRuleSource.find(rule => 
                (!rule.postId || rule.postId === "") && 
                commentText.toLowerCase().includes((rule.triggerWord || '').toLowerCase())
              );
              if (matchedRule) console.log(`🌍 [Match Engine] Fallback global keyword rule matched: '${matchedRule.triggerWord}'`);
            }
          }

          if (!matchedRule && incomingWorkspaceId === 'main') {
              matchedRule = (user.autoReplies || []).find(rule => commentText.toLowerCase().includes((rule.triggerWord || '').toLowerCase()));
              if (matchedRule) console.log(`[Match Engine] Main autoReplies fallback matched: '${matchedRule.triggerWord}'`);
          } else if (!matchedRule) {
              console.log("[Match Engine] Skipping main autoReplies fallback because webhook belongs to a workspace page.");
          }

          console.log("[MATCH SUMMARY] FINAL MATCHED RULE OBJECT =", matchedRule);
          console.log("========================================================\n");

          if (matchedRule) {
             console.log(`✅ [Instagram Webhook] Token Context Trigger Lock: '${matchedRule.triggerWord}'`);
             let finalReplyMsg = matchedRule.replyMessage;
             if (matchedRule.fileUrl && matchedRule.deliveryMode !== 'button') {
                 finalReplyMsg += `\n\n📄 Here is your link/file: ${matchedRule.fileUrl}`;
             }
             
             if (isPostSpecific) {
               if (incomingWorkspaceId !== 'main') {
                 await User.updateOne(
                   { _id: user._id, "workspaces._id": incomingWorkspaceId },
                   { $inc: { "workspaces.$.postAutomations.$[elem].stats.sentCount": 1 } },
                   { arrayFilters: [{ "elem.postId": mediaId }] }
                 ).catch(e => console.log('Workspace sent count increment error:', e.message));
               } else {
                 await User.updateOne(
                   { _id: user._id, "postAutomations.postId": matchedRule.postId },
                   { $inc: { "postAutomations.$.stats.sentCount": 1 } }
                 ).catch(e => console.log('Main sent count increment error:', e.message));
               }
             }
             
             let dmSentSuccessfully = false;
             const rateKey = `ig_reply_count:${igAccountId}:${threadId}`;
             try {
               const replyCount = await redis.incr(rateKey);
               if (replyCount === 1) await redis.expire(rateKey, 10 * 60); 
               if (replyCount > 5) {
                 console.log(`Skipped: rate limit exceeded for thread ${threadId} (count=${replyCount})`);
                 await Message.create({ userId: user._id, workspaceId: incomingWorkspaceId, customerPhone: `IG_${igUserId}`, channel: 'instagram_comment', messageText: `[SYSTEM] Reply skipped due to rate limit for this thread. Count=${replyCount}`, direction: 'outgoing', status: 'skipped', sentBy: 'system', tags: ['ig_rate_limited'], timestamp: new Date(), expiresAt: getMessageExpiry(user, 'instagram_comment') });
                 continue;
               }
             } catch (e) {
               console.error('⚠️ [Redis RateLimit] Error incrementing rate key:', e.message);
             }

             try {
               if (igToken) {
                 if (matchedRule.deliveryMode === 'instant_shortcut' || matchedRule.deliveryMode === 'direct') { // This is a DM
                    const compiledShortcutMsg = `${matchedRule.replyMessage}\n\n🔗 Link: ${matchedRule.fileUrl}`;
                    
                    console.log("\n====================================================");
                    console.log("🕵️‍♂️ [DIAGNOSIS ENGINE] RUNNING DIRECT USER_ID OVERRIDE");
                    console.log("👉 TARGET EXTRACTED USER NAME:", username);
                    console.log("👉 TARGET EXTRACTED USER ID (igUserId):", igUserId);
                    console.log("👉 TARGET PAGE ID (for FB flow):", igPageId);
                    console.log("👉 IG TOKEN PRESENT:", Boolean(igToken));
                    console.log("👉 LOGIN TYPE:", loginType);
                    console.log("====================================================");
                    
                    await metaAdsService.sendInstagramCommentPrivateReply(igToken, igPageId, commentData.id, compiledShortcutMsg, loginType);
                    dmSentSuccessfully = true;
                 } 
                 else if (matchedRule.deliveryMode === 'button') { // This is a DM
                    const fallbackText = `${matchedRule.replyMessage}\n\n🔗 Link: ${matchedRule.fileUrl}`;
                    await metaAdsService.sendInstagramCommentPrivateReply(igToken, igPageId, commentData.id, fallbackText, loginType);
                    dmSentSuccessfully = true;
                 }
                 else { // This is a DM
                    await metaAdsService.sendInstagramCommentPrivateReply(igToken, igPageId, commentData.id, finalReplyMsg, loginType);
                    dmSentSuccessfully = true;
                 }
               }
             } catch (replyErr) {
               console.error("❌ [Meta Graph Private Reply / Direct DM Error]:", {
                 message: replyErr.message,
                 status: replyErr.response?.status,
                 data: replyErr.response?.data,
                 pageId: igPageId,
                 commentId: commentData.id
               });
             }

             if (dmSentSuccessfully) {
               try {
                 // ✅ FIX 3a: matched-rule public comment reply now checks both native-login values
                 const commentReplyUrl = isInstagramNativeLogin(loginType)
                    ? `https://graph.instagram.com/v21.0/${commentData.id}/replies`
                    : `https://graph.facebook.com/v19.0/${commentData.id}/replies`;
                 await axios.post(commentReplyUrl, {
                     message: matchedRule.publicReply || `Hey @${username}, we've sent you a DM with the details! 📩`,
                     access_token: igToken
                 }, { params: { access_token: igToken } });
               } catch (publicErr) {
                 console.error("❌ [Meta Public Reply Comment Error]:", publicErr.message);
               }
             }
             
             const finalLoggedMsg = (matchedRule.deliveryMode === 'instant_shortcut' || matchedRule.deliveryMode === 'direct') 
                ? `${matchedRule.replyMessage}\n\n🔗 Link: ${matchedRule.fileUrl}` 
                : finalReplyMsg;
             
             await Message.create({ userId: user._id, workspaceId: incomingWorkspaceId, customerPhone: `IG_${igUserId}`, channel: 'instagram_comment', messageText: `[💬 IG Comment]: ${commentText}`, direction: 'incoming', status: 'received', sentBy: 'customer', tags: ['ig_comment', 'auto_replied'], timestamp: new Date(), expiresAt: getMessageExpiry(user, 'instagram_comment', 'incoming') });
             await Message.create({ userId: user._id, workspaceId: incomingWorkspaceId, customerPhone: `IG_${igUserId}`, channel: 'instagram_dm', messageText: finalLoggedMsg, direction: 'outgoing', status: dmSentSuccessfully ? 'sent' : 'failed', sentBy: 'auto-reply', tags: ['ig_private_reply'], timestamp: new Date(), expiresAt: getMessageExpiry(user, 'instagram_dm', 'auto-reply') });
          } else {
             const accountAiEnabled = incomingWorkspaceId !== 'main'
               ? activeWorkspaceNode?.aiAgentEnabled !== false
               : user.aiAgentEnabled !== false;
             const commentAiGloballyEnabled = incomingWorkspaceId !== 'main'
               ? activeWorkspaceNode?.commentAiReplyEnabled === true
               : user.commentAiReplyEnabled === true;
             const workspacePostSettings = incomingWorkspaceId !== 'main'
               ? (activeWorkspaceNode?.commentAiPostSettings || [])
               : (user.commentAiPostSettings || []);
             const postCommentAiConfig = mediaId
               ? workspacePostSettings.find(setting => String(setting.postId) === String(mediaId))?.commentAiReplyEnabled
               : undefined;
             const isCommentAiEnabled = accountAiEnabled && commentAiGloballyEnabled && (postCommentAiConfig !== false);

             if (!isCommentAiEnabled) {
               console.log('Skipped: AI comment replies disabled for this account/post or AI agent is turned off.');
               continue;
             }

             if (threadState.humanTookOver) {
               console.log(`Skipped: human takeover active for thread ${threadId}. AI comment replies are disabled until owner re-enables.`);
               continue;
             }

             if (threadState.pausedUntil && new Date(threadState.pausedUntil) > new Date()) {
               console.log(`Skipped: thread ${threadId} is paused until ${threadState.pausedUntil}.`);
               continue;
             }

             if (threadState.aiReplyCount >= 3 && !threadState.manualOverride) {
               console.log(`Skipped: AI reply cap (3) reached for thread ${threadId}, needs owner review.`);
               continue;
             }

             try {
                 let aiContext = `You are the friendly social media manager for ${user.businessName || 'this page'}. Reply to this Instagram comment: "${commentText}".`;
                 aiContext += "\n\n[COMMENT AI RULES]: If the comment is just emoji, generic praise, spam, or does not need a response, reply with exactly NO_REPLY_NEEDED. Do not repeat similar phrasing to your last replies in this thread. Only answer what was actually asked, and do not initiate a new topic.";
                 aiContext += "\n\nKeep your reply extremely short, polite, and focused only on the comment. If you are sending a public reply, keep it under 15 words.";
                 const aiReply = await aiService.generateAIResponse(commentText, aiContext, 'instagram');

                 if (!aiReply || aiReply.trim().toUpperCase().includes('NO_REPLY_NEEDED')) {
                   console.log(`Skipped: AI decided NO_REPLY_NEEDED for thread ${threadId}.`);
                   threadState.lastAuthorId = igUserId;
                   await saveThreadState(threadKey, threadState);
                   continue;
                 }

                 // ✅ FIX 3b: AI comment reply now checks both native-login values
                 const commentReplyUrl = isInstagramNativeLogin(loginType)
                    ? `https://graph.instagram.com/v21.0/${commentData.id}/replies`
                    : `https://graph.facebook.com/v19.0/${commentData.id}/replies`;
                 const replyResponse = await axios.post(commentReplyUrl, {
                     message: aiReply,
                     access_token: igToken
                 }, { params: { access_token: igToken } });

                 const replyCommentId = replyResponse?.data?.id || null;
                 threadState.aiReplyCount = (threadState.aiReplyCount || 0) + 1;
                 threadState.lastAuthorId = igAccountId;
                 threadState.lastAiCommentId = replyCommentId;
                 await saveThreadState(threadKey, threadState);

                 await Message.create({ // Log the public AI reply
                   userId: user._id, customerPhone: `IG_${igUserId}`,
                   channel: 'instagram_comment',
                   messageText: `[Public AI Reply]: ${aiReply}`,
                   direction: 'outgoing', status: 'sent', sentBy: 'ai',
                   tags: ['ig_comment_reply'], timestamp: new Date(), expiresAt: getMessageExpiry(user, 'instagram_comment', 'ai')
                 });
             } catch (aiCommentErr) {
                 console.error("❌ [Instagram AI Comment Reply Error]:", aiCommentErr.message);
             }
             
             await Message.create({
               userId: user._id,
               customerPhone: `IG_${igUserId}`,
               channel: 'instagram_comment',
               messageText: `[💬 IG Comment - Unhandled]: ${commentText}`,
               direction: 'incoming',
               status: 'received',
               sentBy: 'customer',
               tags: ['ig_comment', 'needs_reply'],
               timestamp: new Date(),
               expiresAt: getMessageExpiry(user, 'instagram_comment', 'incoming')
             });
          } 
        } 
      } 
    } 
  } catch (error) {
    console.error('Instagram Webhook Fatal Error:', error);
  }
};